# CSGO-Twitch-Bot
 Twitch-Bot to interact with CSGO directly via Channelpoint-Rewards
